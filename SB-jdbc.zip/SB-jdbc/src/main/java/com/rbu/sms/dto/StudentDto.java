package com.rbu.sms.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@AllArgsConstructor
public class StudentDto {
	private long id;
	private String name;
	private String email;
	private String address;

	public StudentDto() {
		System.out.println("StudentDto object created..");
	}

}
