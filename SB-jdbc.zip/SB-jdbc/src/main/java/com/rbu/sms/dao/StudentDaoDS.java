package com.rbu.sms.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.rbu.sms.dto.StudentDto;

@Repository
public class StudentDaoDS {
	@Autowired
	DataSource dataSource;

	public StudentDto save(StudentDto dto) {
		// jdbc
		Connection con;
		try {
			con = dataSource.getConnection();
			System.out.println(con);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return dto;
	}

	public StudentDaoDS() {
		System.out.println("StudentDaoDS object created");
	}

}
