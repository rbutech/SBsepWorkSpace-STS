package com.rbu.sms.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.rbu.sms.dto.StudentDto;

@Repository
public class StudentDaoNPJT {
	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	public StudentDto save(StudentDto dto) {
		Map<String, Object> mapData = new HashMap<>();
		mapData.put("id", dto.getId());
		mapData.put("name", dto.getName());
		mapData.put("email", dto.getEmail());
		mapData.put("address", dto.getAddress());
		jdbcTemplate.update("insert into STUDENT values(:id,:name,:email,:address)", mapData);
		return dto;
	}

	public StudentDaoNPJT() {
		System.out.println("StudentDaoNPJT object created");
	}

}
