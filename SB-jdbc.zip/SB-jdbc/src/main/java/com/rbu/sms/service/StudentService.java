package com.rbu.sms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.sms.dao.StudentDaoDS;
import com.rbu.sms.dto.StudentDto;

@Service
public class StudentService {
	@Autowired
	//StudentDao dao;
	//StudentDaoNPJT dao;
	StudentDaoDS dao;

	public StudentDto createStudent(StudentDto dto) {
		return dao.save(dto);
	}
	
	
	public StudentService() {
	System.out.println("StudentService object created");
	}

}
