package com.rbu.sms.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.rbu.sms.dto.StudentDto;

@Repository
public class StudentDao {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public StudentDto save(StudentDto dto) {
		// jdbc
		jdbcTemplate.update("insert into STUDENT values(?,?,?,?)",
				new Object[] { dto.getId(), dto.getName(), dto.getEmail(), dto.getAddress() });
		return dto;
	}
	
	
	public StudentDao() {
	System.out.println("StudentDao object created");
	}

}
