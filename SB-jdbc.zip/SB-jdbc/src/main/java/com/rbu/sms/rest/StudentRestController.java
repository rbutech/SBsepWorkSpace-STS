package com.rbu.sms.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rbu.sms.dto.StudentDto;
import com.rbu.sms.service.StudentService;

@RestController
public class StudentRestController {
	@Autowired
	StudentService service;

	// @RequestMapping(value = "/student",method = RequestMethod.POST)
	@PostMapping("/student")
	public StudentDto createStudent(@RequestBody StudentDto dto) {
		return service.createStudent(dto);
	}

	public StudentRestController() {
		System.out.println("StudentRestController object created");
	}
}
