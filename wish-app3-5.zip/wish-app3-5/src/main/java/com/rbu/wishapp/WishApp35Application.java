package com.rbu.wishapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WishApp35Application {

	public static void main(String[] args) {
		SpringApplication.run(WishApp35Application.class, args);
	}

}
