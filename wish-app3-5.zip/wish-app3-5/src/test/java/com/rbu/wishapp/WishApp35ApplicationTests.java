package com.rbu.wishapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishApp35ApplicationTests {

	@Test
	void contextLoads() {
	}

}
