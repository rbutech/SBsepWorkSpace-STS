package com.rbu.sms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rbu.sms.model.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

@Repository
public class StudentDaoEM {
//	 @PersistenceContext
//	 EntityManager entityManager;
	@Autowired
	EntityManagerFactory factory;

	@Transactional
	public Student save(Student student) {
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		em.merge(student);
		em.flush();
		em.getTransaction().commit();
		em.close();
		return student;
	}

	public Student update(Student student) {
		EntityManager em = factory.createEntityManager();
		em.persist(student);
		em.flush();
		em.close();
		return student;
	}

	public void delete(Student student) {
		EntityManager em = factory.createEntityManager();
		em.remove(student);
	}

	public Student findById(Long id) {
		EntityManager em = factory.createEntityManager();
		return em.find(Student.class, id);
	}

	public List<Student> findAll() {
		EntityManager em = factory.createEntityManager();
		return em.createQuery("from com.rbu.sms.model.Student").getResultList();
	}

	public boolean existsById(Long id) {
		EntityManager em = factory.createEntityManager();
		Student student = em.find(Student.class, id);
		if (null != student)
			return true;
		else
			return false;
	}
	public Student findWithNativeQuery(Student student) {
		EntityManager em = factory.createEntityManager();
		Query q1=em.createNativeQuery("select max(id) from STUDENT");
		int maxid=(int) q1.getSingleResult();
		Query q2=em.createNativeQuery("select name from STUDENT");
		String name=(String)q2.getSingleResult();
		Query q3=em.createNativeQuery("select name,email from STUDENT");
		List list=q3.getResultList();
		return student;
	}


}
