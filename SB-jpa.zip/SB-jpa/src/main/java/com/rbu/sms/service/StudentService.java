package com.rbu.sms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.sms.dao.StudentDaoEM;
import com.rbu.sms.dto.StudentDto;
import com.rbu.sms.model.Student;

@Service
public class StudentService {
	@Autowired
	StudentDaoEM dao;
	//StudentDaoInterface dao;

	public StudentDto createStudent(StudentDto dto) {
		Student student = new Student();
		BeanUtils.copyProperties(dto, student);
		dto.setId(dao.save(student).getId());
		return dto;
	}

	public StudentDto updateStudent(StudentDto dto) throws UserNotFound {
		if (dao.existsById(dto.getId())) {
			Student student = new Student();
			BeanUtils.copyProperties(dto, student);
			dao.save(student);
		} else
			throw new UserNotFound("user not exit to update");
		return dto;
	}

	public StudentDto deleteStudent(StudentDto dto) throws UserNotFound {
		if (dao.existsById(dto.getId())) {
			Student student = new Student();
			BeanUtils.copyProperties(dto, student);
			dao.delete(student);
		} else
			throw new UserNotFound("user not exit to delete");
		return dto;
	}

	public StudentDto findStudent(StudentDto dto) throws UserNotFound {
		if (dao.existsById(dto.getId())) {
			Student student = dao.findById(dto.getId());
			BeanUtils.copyProperties(student, dto);
			return dto;
		} else
			throw new UserNotFound("user not exit to select");

	}
	public List<StudentDto> findAll() throws UserNotFound {
		List<StudentDto> dtolist=new ArrayList<>();
		List<Student> list=dao.findAll();
		if (!list.isEmpty()) {
				for(Student std:list) {
					StudentDto dto=new StudentDto();
					BeanUtils.copyProperties(std, dto);
					dtolist.add(dto);
				}

			return dtolist;
		} else
			throw new UserNotFound("No user record found");

	}
	public void testMethod() {
		dao.findWithNativeQuery(new Student());
	}

	public StudentService() {
		System.out.println("StudentService object created");
	}

}
