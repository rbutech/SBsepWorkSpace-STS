package com.rbu.sms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rbu.sms.model.Student;

public interface StudentDaoInterface extends JpaRepository<Student,Long>{
//here by default all 37 parent interface methods will imported and 
	//springboot will provide implementation for all 37/27 methods
//custom methods 2 styles
}
