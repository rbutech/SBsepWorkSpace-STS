package com.rbu.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan("com.rbu.sms.model")
@EnableJpaRepositories("com.rbu.sms.dao")
public class SbJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbJpaApplication.class, args);
	}

}
