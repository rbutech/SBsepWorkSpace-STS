package com.rbu.sms.service;

import lombok.ToString;

@ToString
public class UserNotFound extends Exception {
	private String message;

	public UserNotFound(String message) {
		this.message = message;

	}

}
