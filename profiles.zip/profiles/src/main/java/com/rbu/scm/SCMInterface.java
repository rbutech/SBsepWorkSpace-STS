package com.rbu.scm;

public interface SCMInterface {

	public void creditSalary();

}
