package com.rbu.scm.mh;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("mh")
public class MHSCMComponent {
	public MHSCMComponent() {
		System.out.println("MHSCMComponent object created");
	}
	public void salaryCreditCal() {
		System.out.println("MH SGT is 11%");
	}
	
}
