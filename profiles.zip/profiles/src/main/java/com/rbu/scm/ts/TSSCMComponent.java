package com.rbu.scm.ts;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("ts")
public class TSSCMComponent {
	public TSSCMComponent() {
		System.out.println("TSSCMComponent object created");
	}

	public void salaryCreditCal() {
		System.out.println("TS SGT is 12%");
	}

}
