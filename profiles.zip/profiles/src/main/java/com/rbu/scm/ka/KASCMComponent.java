package com.rbu.scm.ka;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("ka")
public class KASCMComponent {

	public KASCMComponent() {
		System.out.println("KASCMComponent object created");
	}

	public void salaryCreditCal() {
		System.out.println("KA SGT is 10%");
	}

}
