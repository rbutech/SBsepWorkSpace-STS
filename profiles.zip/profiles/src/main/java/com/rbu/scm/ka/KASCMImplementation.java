package com.rbu.scm.ka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.rbu.scm.SCMInterface;

@Service
@Profile("ka")
public class KASCMImplementation implements SCMInterface {
	@Autowired
	KASCMComponent component;

	public KASCMImplementation() {
		System.out.println("KASCMImplementation object created");
	}

	@Override
	public void creditSalary() {
		component.salaryCreditCal();
		System.out.println("credit salary to KA");

	}

}
