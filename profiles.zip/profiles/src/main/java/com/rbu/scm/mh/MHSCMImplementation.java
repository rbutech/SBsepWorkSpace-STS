package com.rbu.scm.mh;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.rbu.scm.SCMInterface;

@Service
@Profile("mh")
public class MHSCMImplementation implements SCMInterface {
	@Autowired
	MHSCMComponent component;

	public MHSCMImplementation() {
		System.out.println("MHSCMImplementation object created");
	}

	@Override
	public void creditSalary() {
		component.salaryCreditCal();
		System.out.println("credit salary to MH");

	}

}
