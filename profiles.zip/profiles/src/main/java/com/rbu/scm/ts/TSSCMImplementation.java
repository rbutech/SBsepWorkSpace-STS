package com.rbu.scm.ts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.rbu.scm.SCMInterface;

@Service
@Profile("ts")
public class TSSCMImplementation implements SCMInterface {
	@Autowired
	TSSCMComponent component;
	
	public TSSCMImplementation() {
		System.out.println("TSSCMImplementation object created");
	}

	@Override
	public void creditSalary() {
		component.salaryCreditCal();
		System.out.println("credit salary to TS");

	}

}
