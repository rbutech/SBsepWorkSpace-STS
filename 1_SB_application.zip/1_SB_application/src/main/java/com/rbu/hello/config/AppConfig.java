package com.rbu.hello.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	public AppConfig() {
		System.out.println("AppConfig object  created...");
	}

	@Bean
	public Object createYourBean() {
		System.out.println("creating YourBean");
		return "My Object";
	}

}
