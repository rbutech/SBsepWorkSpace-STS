package com.rbu.hello.repo;

import org.springframework.stereotype.Repository;

@Repository
public class HelloRepo {
	public HelloRepo() {
	System.out.println("HelloRepo object created..");
	}
	public void save() {
		System.out.println("save ...");
	}
}

