package com.rbu.hello.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.hello.repo.HelloRepo;

@Service
public class HelloService {
	@Autowired
	HelloRepo helloRepo;
	public HelloService() {
	System.out.println("HelloService object created..");
	}
	
	public void hello() {
		System.out.println("Hello.... from service");
		helloRepo.save();
	}
}

