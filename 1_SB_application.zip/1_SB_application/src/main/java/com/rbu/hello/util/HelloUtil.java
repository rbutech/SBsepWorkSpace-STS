package com.rbu.hello.util;

import org.springframework.stereotype.Component;

@Component
public class HelloUtil {
	public HelloUtil() {
		System.out.println("HelloUtil object created");
	}
}
