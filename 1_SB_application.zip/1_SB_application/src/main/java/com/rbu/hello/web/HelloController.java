package com.rbu.hello.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.hello.service.HelloService;

@Controller
public class HelloController {
	@Autowired
	HelloService helloService;

	public HelloController() {
		System.out.println("HelloController object created");
		
	}
	public void hello() {
		helloService.hello();
	}

}
