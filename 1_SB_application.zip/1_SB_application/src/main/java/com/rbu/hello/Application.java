package com.rbu.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.rbu.hello.web.HelloController;

@SpringBootApplication(scanBasePackages = {"com.rbu.hai","com.rbu.hello"})
//@ComponentScan("com.rbu.hello.*")
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext ap = SpringApplication.run(Application.class, args);
		HelloController hc = ap.getBean(HelloController.class);
		hc.hello();
		ap.close();
	}

}
