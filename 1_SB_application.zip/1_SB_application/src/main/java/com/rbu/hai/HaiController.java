package com.rbu.hai;

import org.springframework.stereotype.Controller;

@Controller
public class HaiController {
public HaiController() {
System.out.println("HaiController... oobject createed....");
}
}
