package com.rbu.wishapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishApp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
