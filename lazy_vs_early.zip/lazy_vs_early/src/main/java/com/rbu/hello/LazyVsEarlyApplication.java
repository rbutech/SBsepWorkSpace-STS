package com.rbu.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class LazyVsEarlyApplication {

	public static void main(String[] args) {
		ApplicationContext ap=SpringApplication.run(LazyVsEarlyApplication.class, args);
		TestBean t1=ap.getBean(TestBean.class);
		TestBean t2=ap.getBean(TestBean.class);
		System.out.println(t1==t2);
	}

}
